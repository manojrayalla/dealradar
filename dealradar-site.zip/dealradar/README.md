# DealRadar
Static starter for a responsive deal discovery dashboard.


## Included
- Responsive UI, search and category filters
- Sort by score, discount, price
- Saved deals persisted in browser localStorage
- Search links to retailer/product query
- Illustrative deal data only (not live retailer prices)

## Publish via GitHub Pages
1. Create a new GitHub repository named `dealradar`.
2. Upload `index.html` and this README at the repository root.
3. In repository Settings -> Pages, choose **Deploy from a branch**, select `main` and `/ (root)`, Save.
4. Wait for the GitHub Pages workflow to finish. Your public URL should be `https://YOUR-USERNAME.github.io/dealradar/`.

This is a static front end. To make it show verified, real-time deals, add a server-side scheduled feed/API collector (never expose private API keys in client-side code) and replace the demo data in the `deals` array.
